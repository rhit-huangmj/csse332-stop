#include "kernel/types.h"
#include "user/user.h"
#include "kernel/fs.h"
#include "kernel/stat.h"

int main(int argc, char **argv)
{
  /* TODO: Insert your code here. */

  exit(0);
}
